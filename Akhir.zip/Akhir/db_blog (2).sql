-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 02:28 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `id` int(11) NOT NULL,
  `album_name` varchar(100) NOT NULL,
  `album_seo` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `is_active` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `album_name`, `album_seo`, `photo`, `is_active`) VALUES
(17, 'Album 1', 'album-1', 'album-1-1581343722711.jpg', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `title`, `photo`) VALUES
(5, 'Home', 'fa9d970cb994ec5b6b12d5b69e1e4387.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `is_active` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `slug`, `is_active`) VALUES
(6, 'Teknologi', 'teknologi', 'Y'),
(9, 'Akademik', 'akademik', 'Y'),
(13, 'Olahraga', 'olahraga', 'Y'),
(14, 'Entertaiment', 'entertaiment', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `contact_name`, `description`) VALUES
(1, 'About Me', 'Ini adalah project portal berita dan artikel sederhana, yang bertujuan menyelesaikan tugas project team.');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `id_album` int(11) NOT NULL,
  `gallery_name` varchar(100) NOT NULL,
  `gallery_seo` varchar(100) NOT NULL,
  `information` text NOT NULL,
  `photo` varchar(100) NOT NULL,
  `is_active` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `id_album`, `gallery_name`, `gallery_seo`, `information`, `photo`, `is_active`) VALUES
(9, 17, 'Galeri 2', 'galeri-2', 'LIfe is Strange', 'galeri-2-15815614412.jpg', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `identity`
--

CREATE TABLE `identity` (
  `id` int(11) NOT NULL,
  `web_name` varchar(255) NOT NULL,
  `web_address` varchar(255) NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `identity`
--

INSERT INTO `identity` (`id`, `web_name`, `web_address`, `meta_description`, `meta_keyword`, `photo`) VALUES
(1, 'sijaupdate.com', 'sijaupdate.com', 'Berita Indonesia dan Dunia Terbaru Hari Ini, Berita Harian Terlengkap Terbaru Seputar, Teknologi, Akdemik, Wisata, Olahraga', 'SIJA UPDATE', 'ff5129124269026b13183b5eac750e42.png');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES
(12, '::1', 'anis', 1675298357);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `is_active` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 'Pengaturan Web', '', 'fas fa-fw fa-cog', 'Y'),
(2, 'Menu', '', 'fas fa-fw fa-sliders-h', 'Y'),
(3, 'Manajemen Artikel', '', 'fas fa-fw fa-newspaper', 'Y'),
(4, 'Media', '', 'fas fa-fw fa-photo-video', 'Y'),
(5, 'Profile', 'home', 'fas fa-fw fa-home', 'Y'),
(6, 'Logout', 'auth/logout', '', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `posting`
--

CREATE TABLE `posting` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `featured` char(1) NOT NULL,
  `choice` char(1) NOT NULL,
  `thread` char(1) NOT NULL,
  `id_category` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `is_active` char(1) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posting`
--

INSERT INTO `posting` (`id`, `title`, `seo_title`, `content`, `featured`, `choice`, `thread`, `id_category`, `photo`, `is_active`, `date`) VALUES
(96, 'Apple Baru Saja Rilis iOS 16.3, Apa Saja Fitur Barunya?', 'apple-baru-saja-rilis-ios-16-3-apa-saja-fitur-barunya', 'Sijaupdate.com- Apple resmi merilis iOS 16.3 untuk semua perangkat yang mendukung pembaruan tersebut. Apa saja fitur terbarunya?\r\nMelansir GSM Arena, iOS terbaru ini dilengkapi dukungan untuk kunci keamanan (Security Keys) untuk Apple ID. Fitur itu membuat pengguna bisa menerapkan otentikasi dua faktor secara fisik saat masuk (log in) ke Apple ID mereka.\r\n\r\nApple juga menyematkan fitur Emergency SOS pada iOS 16.3. Fitur ini sebetulnya sudah diperkenalkan pada acara Apple, September lalu.\r\n\r\nPada iOS 16.3 opsi Call with Hold (panggil dengan tahan) digantikan Call with Hold and Release (panggil dengan tahan dan lepas).\r\n\r\nJika pengguna mengaktifkan fitur Call with Hold and Release, pengguna dapat menahan tombol di samping (side button) dan tombol volume untuk memulai hitung mundur serta alarm.\r\n\r\nPada versi sebelumnya, pengguna lewat Call with Hold harus menekan tombol samping dan volume untuk menghadirkan penggeser (slider) Emergency SOS.\r\n\r\nSetelahnya, jika pengguna menahan dua tombo tersebut, hitung mundur akan berakhir dan ponsel Anda akan membuat panggilan darurat.\r\n\r\nLebih lanjut, Apple juga menambal celah keamanan yang terdapat pada versi sebelumnya. Pada iOS 16.3 Apple memberikan tambalan itu untuk Apple Mobile File Integrity, ImageIO, Kernel, Mail, Maps, Safari, dan WebKit.\r\n\r\nContoh celah keamanan yang ada aplikasi cuaca (Weather app) bisa membuat peretas masuk ke preferensi privasi pengguna yang jadi targetnya.\r\n\r\nSelain itu, Apple juga telah menutup dua celah keamanan pada WebKit yang menjadi penggerak untuk Safari serta peramban lain di iOS. Berikut daftar pembaruan pada iOS 16.3.\r\n\r\n- Wallpaper baru untuk menghargai sejarah orang kulit hitam dalam rangka perayaan Black History Month.\r\n\r\n- Security Keys untuk Apple ID yang membuat pengguna dapat lebih menguatkan keamanan akun masing-masing dengan cara menerapkan kunci keamanan fisik sebagai bagian dari otentikasi dua faktor.\r\n\r\n- Emergency SOS yang kini diterapkan dengan cara menahan tombol samping bersama dengan tombol volume naik atau turun kemudian melepasnya supaya mencegah panggilan darurat yang tak disengaja.\r\n\r\n- Menuntaskan masalah di Freeform.\r\n\r\n- Menuntaskan masalah wallpaper yang kadang menjadi hitam di Lock Screen.\r\n\r\n- Menuntaskan masalah di mana garis horizontal mungkin terkadang muncul ketika mengaktifkan iPhone 14 Pro Max.\r\n\r\n- Menuntaskan masalah widget di Home Lock Screen yang kadang tidak akurat menampilkan status aplikasi di Home.\r\n\r\n- Menuntaskan masalah Siri yang kadang tidak merespon dengan tepat permintaan untuk musik\r\n\r\n- Menyelesaikan masalah Siri dalam fitur CarPlay.', 'Y', 'Y', 'Y', 6, '170706ea546995844f8aea03a7538fd2.jpeg', 'Y', '2023-02-01'),
(97, 'Incognito Mode Chrome Android Kini Bisa Dikunci, Buka Wajib Pakai \"Fingerprint\"', 'incognito-mode-chrome-android-kini-bisa-dikunci-buka-wajib-pakai-fingerprint', 'Sijaupdate.com- Google meluncurkan fitur privasi baru untuk peramban (browser) Chrome. Fitur anyar ini dapat ditemui di mode penyamaran alias Incognito Chrome versi Android. Fitur privasi baru itu bernama \"Lock Incognito tab when you leave Chrome\" (kunci tab Incognito ketika meninggalkan Chrome). Dalam situs resminya, Google mengungkapkan bahwa fitur ini dihadirkan untuk merayakan Hari Privasi Data. Sesuai namanya, fitur \"Lock Incognito Tab When You Leave\" Chrome ini memungkinkan pengguna mengunci tab yang dibuka dalam mode Incognito. Tab tersebut akan terkunci ketika pengguna keluar dari aplikasi Chrome di ponsel Android. Ketika akan membuka kembali mode Incognito, pengguna akan diwajibkan melakukan autentikasi biometrik dengan pemindai sidik jari atau fingerprint scanner.  Selama ini, mode Incognito banyak digunakan karena bisa membuat aktivitas penjelajahan internet dirahasiakan atau tak terekam. Tak jarang ketika ingin meninggalkan Chrome, pengguna menutup semua tab di mode Incognito agar privasi tetap terjaga.\r\n\r\nFitur penguncian mode Incognito di aplikasi Chrome di ponsel Android ini sifatnya opsional. Jadi, pengguna perlu mengaktifkannya secara mandiri. Berikut panduan untuk mengaktifkan fitur penguncian pada mode Incognito di Google Chrome: Buka aplikasi Chrome di ponsel Android Klik ikon titik tiga di pojok kanan atas Klik \"Settings\" Pilih \"Privacy and security\" Pengguna bakal melihat opsi \"Lock Incognito tabs when you leave Chrome. Use screen lock to see open Incognito tabs\". Geser toggle ke arah \"on\" Maka, tab di mode Incognito bakal diamankan dengan fingerprint ketika akan dibuka. Pantauan KompasTekno, Senin (30/1/2023), fitur \"Lock Incognito tabs when you leave Chrome. Use screen lock to see open Incognito tabs\" belum tersedia di aplikasi Chrome versi 109.0.5414.117 di ponsel Android. Dalam situs resminya, Google mengatakan fitur ini sedang digelontorkan ke pengguna Android. Tampaknya perlu beberapa waktu untuk fitur ini bisa tersedia dan dinikmati seluruh pengguna aplikasi Google Chrome di Android. Jadi, kita tunggu saja.', 'Y', 'Y', 'N', 6, '9abdfdca9f197d7ff81fedd3cd04183d.jpeg', 'Y', '2023-02-01'),
(98, 'Sinyal Wifi Bisa Dipakai \"Melihat\" Orang di Balik Tembok', 'sinyal-wifi-bisa-dipakai-melihat-orang-di-balik-tembok', 'Sijaupdate.com- Sinyal WiFi diklaim bisa dipakai untuk melihat manusia di balik dinding atau tembok, alias tembus pandang. Setidaknya begitu menurut hasil penelitian sejumlah ilmuwan di Carnegie Mellon University, Pennsylvania, Amerika Serikat. Para peneliti itu memanfaatkan jaringan neural (neural network) yang disebut DensePose serta dua router WiFi. Jaringan neural yang dikembangkan oleh para peneliti di Imperial College London, Facebook AI dan University College London ini mampu merepresentasikan tubuh manusia berkat dukungan kecerdasan buatan. \r\n\r\n Dalam penelitian ini, DensePose bertugas memetakan sinyal WiFi ke koordinat UV atau permukaan model 3D yang diproyeksikan ke gambar 2D agar bisa diproses ke komputer. Berdasarkan penelitian, DensePose diklaim mampu memetakan beberapa pose manusia dengan sensor 1D atau antena WiFi, ketimbang memakai kamera RGB atau teknologi LiDAR yang lebih mahal. Jadi, sinyal WiFi juga bisa dipakai untuk memetakan pose manusia, sekaligus mendeteksi keberadaannya secara akurat di balik dinding. \"Hasil studi menunjukkan bahwa model (pendekatan) kami bisa memperkirakan pose dari beberapa subjek, sama seperti pendekatan berbasis gambar, hanya dengan memanfaatkan sinyal WiFi sebagai satu-satunya sumber (input),\" kata Jiaqi Geng, Dong Huang, dan Fernando De la Torre, peneliti yang terlibat dalam riset ini dalam makalah berjudul \"DensePose From WiFi\". Mereka juga menjelaskan bahwa pemanfaatan sinyal WiFi ini menjadi peluang untuk penerapan teknologi berbiaya rendah, bisa diakses banyak orang dan algoritma perlindungan privasi penginderaan manusia. \r\n\r\nSelain lebih terjangkau, pendekatan WiFi untuk pencitraan manusia juga bisa dilakukan meskipun kondisi gelap atau minim cahaya maupun terdapat penghalang seperti dinding. Selain itu, pendekatan WiFi melindungi privasi individu dan alat yang dibutuhkan bisa dibeli dengan harga yang terjangkau,\" tulis para peneliti. Selanjutnya, pendekatan ini menurut para peneliti bisa diterapkan untuk perawatan kesehatan di rumah, dilansir KompasTekno dari ZDNet. Misalnya ketika pasien mungkin tidak ingin dipantau oleh kamera atau alat lain, khususnya di tempat seperti kamar mandi. Sebab, tidak semua properti dicitrakan, melainkan hanya beberapa objek penting seperti manusia. Skenario lainnya yang juga bisa diterapkan, misalnya untuk memantau kesehatan orang lanjut usia (lansia) atau mengidentifikasi perilaku mencurigakan di rumah.', 'Y', 'Y', 'Y', 6, '2b75a390616d2c2592b59e00bc14acdc.jpeg', 'Y', '2023-02-01'),
(99, 'Video Kemampuan Zoom dan Kamera 200 MP Samsung Galaxy S23 Ultra Beredar', 'video-kemampuan-zoom-dan-kamera-200-mp-samsung-galaxy-s23-ultra-beredar', 'Sijaupdate.com- Seiring dengan tanggal peluncuran yang semakin dekat, bocoran spesifikasi dari ponsel flagship teranyar Samsung semakin mencuat.\r\n\r\nKini, beredar sebuah video yang memamerkan kemampuan kamera 200 MP dan zoom dari smartphone yang konon bernama Samsung Galaxy S23 Ultra.\r\n\r\nSamsung Galaxy S23 Ultra sendiri akan menjadi model tertinggi dari Galaxy S23 series. \r\nKeunggulan kamera tersebut dipamerkan dalam bentuk video oleh salah seorang karyawan toko ritel yang berbasis di Nicaragua, Amerika Tengah. \r\n\r\nDikarenakan Instagram Stories hanya bertahan selama 24 jam saja, salah satu pembocor gadget bernama Alvin mengabadikannya dan mengunggah kembali video tersebut di akun Twitter pribadinya dengan handle @sondesix. \r\n\r\n“Samsung Galaxy S23 Ultra. Salah satu orang di toko yang memiliki perangkat tersebut telah melakukan beberapa pengujian kamera. Ini merupakan pengujian fitur zoom kamera,” tulis @sondesix.', 'Y', 'Y', 'Y', 6, '61473f0d015c7b85f785d38d55d0c8f2.jpeg', 'Y', '2023-02-01'),
(100, '5 Dampak Positif Perkembangan Iptek bagi Kehidupan Manusia', '5-dampak-positif-perkembangan-iptek-bagi-kehidupan-manusia', 'Sijaupdate.com- Perkembangan ilmu pengetahuan dan teknologi (iptek) memiliki pengaruh yang luar biasa pada beragam sektor kehidupan. Kemajuan teknologi ini yang membuat aspek kehidupan lebih cepat, praktis, dan semakin mudah. Salah satunya dalam bidang komunikasi. Kemajuan teknologi komunikasi ini yang membuat masyarakat lebih mudah terhubung meskipun dari jarak yang sangat jauh. Apabila dulu saat berkomunikasi jarak jauh pengguna hanya dapat mendengar suara pengguna lain. Saat ini muncul video conference yang memudahkan pengguna bisa berinteraksi tatap muka dengan lancar. Selain dalam bidang komunikasi tentu masih banyak dampak positif dari perkembangan iptek. Selengkapnya KompasTekno merangkum dampak positif iptek yang dilansir dari situs m-edukasi.kemdikbud.go.id. Bidang informasi dan komunikasi Akses informasi lebih cepat dan akurat dari berbagai belahan dunia. Mudahnya berkomunikasi dengan rekan dan keluarga meski berada di lokasi yang sangat jauh. Layanan bank lebih cepat dan mudah dengan adanya fasilitas e-banking. Bidang ekonomi Pertumbuhan ekonomi semakin tinggi. Pesatnya perkembangan industri yang dapat meningkatkan kualitas hidup bagi masyarakat. Produktivitas dunia industri semakin meningkat. Penyerapan tenaga kerja dan kualifikasinya semakin meningkat. Banyak para ahli berpendapat saat ini semakin besar porsi wanita yang memegang posisi sebagai pemimpin, baik dalam dunia pemerintahan maupun dunia bisnis. Timbulnya kelas menengah baru, seperti keterampilan serta gaya hidup kini tak jauh berbeda dengan kelas menengah di negara Barat. Lahirnya generasi disiplin, tekun, dan pekerja keras karena adanya kompetisi yang tajam di pelbagai aspek kehidupan. Bidang pendidikan Munculnya media massa elektronik sebagai sumber informasi yang menyajikan beragam pengetahuan secara cepat. Siswa memperoleh sumber informasi semakin luas tak hanya dari guru, tetapi juga beragam situs-situs internet. Munculnya metode pembelajaran baru yang mudah diakses melalui internet. Guru dan siswa semakin mudah dalam proses pembelajaran. Dengan kemajuan teknologi proses pembelajaran menjadi lebih bervariasi. Tak harus tatap muka, tetapi juga dapat melalui beragam aplikasi video conference. Bidang politik Meningkatnya partisipasi aktif dari banyak negara berkembang dalam percaturan politik global. Negara-negara berkembang memberikan kemudahan untuk mengakses setiap informasi politik luar negeri secara cepat dan akurat. Proses regenerasi kepemimpinan yang dapat berdampak dalam gaya dan substansi politik yang diterapkan. Di bidang politik internasional juga dapat menumbuhkan perkembangan regionalisme. Terlebih lagi kemajuan teknologi transportasi menyebabkan meningkatnya kesadaran tersebut. Hal ini yang dapat meningkatkan kerja sama ekonomi.', 'N', 'Y', 'N', 6, '211cd615ca40350199b219d69a95d90b.jpeg', 'Y', '2023-02-01'),
(101, 'Messi Tak Lagi Tonton Cuplikan Final Piala Dunia 2022', 'messi-tak-lagi-tonton-cuplikan-final-piala-dunia-2022', 'Sijaupdate.com- Lionel Messi tampil gemilang dalam final Piala Dunia 2022 yang dimenangkan Argentina. La Pulga sudah \'move on\' dari pertandingan tersebut.\r\nArgentina menjadi juara Piala Dunia 2022 usai menaklukkan Prancis di final. Albiceleste menang adu penalti setelah bermain imbang 3-3 selama 120 menit.\r\n\r\nMessi tampil luar biasa dengan mencetak dua gol sebelum babak penalti. Kapten Argentina itu sukses merengkuh trofi Piala Dunia 2022 dan dinobatkan sebagai pemain terbaik turnamen.\r\n\r\nPiala Dunia menjadi gelar yang paling diidam-idamkan Lionel Messi sepanjang kariernya. Dia akhirnya berhasil membawa Argentina juara setelah sebelumnya meraih medali perak pada edisi 2014.\r\n\r\nKendati demikian, Messi tidak banyak berkomentar usai Argentina juara Piala Dunia. Bintang Paris Saint-Germain itu baru buka-bukaan hampir dua bulan setelah turnamen digelar.\r\n\r\nYa, Messi baru-baru ini menceritakan pengalamannya menjadi juara dunia kepada media Argentina, TyC Sports. Dia mengaku amat bangga dengan prestasinya itu, tapi tidak lagi menonton cuplikan pertandingan final menghadapi Prancis.\r\n\r\n\"Saya melihat cuplikan pertandingan-pertandingan, perayaan orang-orang ketika kami menjadi juara dunia. Namun final itu sendiri, 90 menit, saya tidak menontonnya lagi,\" kata Messi kepada TyC Sports.\r\n\r\nMessi turut mempersembahkan gelar Piala Dunia 2022 untuk legenda Timnas Argentina, mendiang Diego Maradona.\r\n\r\n\"Saya akan senang sekali apabila bisa mempersembahkan itu kepadanya, setidaknya bisa menyaksikan semua ini. Saya pikir dia melihatnya dari atas sana,\" ujar Messi.\r\n\r\n\"Dia dan banyak orang mencintai saya dengan sungguh-sungguh, tidak hanya untuk ini tapi buat semuanya secara umum,\" demikian kata Lionel Messi.', 'Y', 'Y', 'Y', 13, 'e1f1dcf747410f8167d813570a925a52.jpeg', 'Y', '2023-02-01'),
(102, 'Akhirnya, Jonatan Rasakan Gelar Juara BWF Super 500', 'akhirnya-jonatan-rasakan-gelar-juara-bwf-super-500', 'Sijaupdate.com- Jonatan Christie tampil sebagai juara Indonesia Masters 2023. Setelah menunggu cukup lama, Jonatan akhirnya merasakan gelar juara BWF World Tour Super 500.\r\nJonatan menjadi juara Indonesia Masters 2023 setelah mengalahkan kompatriotnya, Chico Aura Dwi Wardoyo, 21-15, 21-13, di Istora GBK, Jakarta, pada Minggu (29/1/2023).\r\n\r\nKemenangan itu pun menjadi gelar pertamanya sejak terakhir kali sukses ia peroleh saat tampil di Swiss Open 2022. Turnamen tersebut merupakan turnamen level Super 300.\r\n\r\n\"Puji Tuhan akhirnya bisa merasakan gelar super 500 atau gelar di atas 300 yang mungkin saya sudah tunggu-tunggu cukup lama. Beberapa tahun saya bersama Coach Irwansyah, selalu dihina, kami gagal. Kami coba lagi, gagal lagi, coba lagi,\" kata Jonatan.\r\n\r\n\"Tapi ya.. saya juga ingin berterima kasih kepada pelatih Irwan yang sudah percaya dengan saya, percaya dengan tim, anak-anaknya, yang tetap buat kami akhirnya bisa tercapai seperti ini. Saya rasa ini buah dari kerja keras kita,\" kata Jonatan.\r\n\r\nJonatan sendiri terakhir menjadi juara di event penting yaitu meraih emas Asian Games 2018. Saat itu, ia sempat dilabeli sebagai pemain muda yang berbakat. Namun, label itu tak lama seiring dengan kegagalannya di sejumlah turnamen bulutangkis level di atas 500.\r\n\r\nIa hanya mampu mengukir catatan emas di New Zealand Open 2019 dan Australia Open 2019, serta terakhir kali Swiss Open 2019. Ketiga turnamen tersebut merupakan turnamen level Super 300.\r\n\r\nTahun lalu, Jonatan sempat menembus final turnamen Super 500 di Korea Open. Namun, dia harus puas jadi runner-up usai dikalahkan Weng Hongyang.\r\n\r\nJonatan pernah nyaris menjadi juara di turnamen level 750 di Japan Open dan French Open 2019. Ia menjadi runner up setelah lajunya dihentikan Kento Momota dan Chen Long.\r\n\r\n\"Ya, itu salah satu tantangan bagi saya sendiri. Tapi ada satu yang saya percaya jika setiap orang itu takdirnya masing-masing. Ada orang yang masih muda bisa menjuarai semua. Ada yang mungkin sampai tunggu dia matang baru bisa,\" kata Jonatan.\r\n\r\n\"Kita tidak tahu kapan kita berhasil. Yang bisa kita lakukan hanya berusaha, hasil sudah diatur Tuhan, itu yang selalu diingatkan coach. Yang penting kita berjuang semaksimal mungkin yang kita bisa,\" dia mempertegas.', 'Y', 'Y', 'Y', 13, '5ca90e5207af95fcee83c5db3e9c9845.jpeg', 'Y', '2023-02-01'),
(103, 'Yamaha Akan Luncurkan Tim MotoGP 2023 di Jakarta', 'yamaha-akan-luncurkan-tim-motogp-2023-di-jakarta', 'Sijaupdate.com- MotoGP 2023 akan dimulai tidak lama lagi. Yamaha dipastikan akan meluncurkan tim dan motor barunya di Jakarta pada 17 Januari nanti.\r\nDikutip dari Crash, pabrikan Jepang itu akan mengungkapkan warna baru untuk Fabio Quartararo dan Franco Morbidelli di \'3S Dealer Meeting\'. Seremoni tersebut merupakan pertemuan dealer terbesar di dunia di dalam jaringan Yamaha.\r\n\r\nYamaha akan menjadi tim MotoGP pertama yang meluncurkan livery terbaru untuk musim 2023. Meski demikian, aktivitas media dengan pebalap dan manajemen tidak akan dilangsungkan sebelum tes resmi MotoGP di Sepang, Malaysia pada 10-12 Februari.\r\n\r\nYamaha fokus pada perbaikan mesin untuk musim depan, tapi mengalami kemunduran yang tidak disangka-sangka ketika desain yang baru gagal memberikan peningkatan top speed pada tes di Valencia, November silam.\r\n\r\nQuartararo dan Morbidelli menjadi hanya dua penunggang M1 di MotoGP 2023, setelah tim satelit RNF memutuskan berpindah ke Aprilia.\r\n\r\nYamaha hanya meraih tiga kemenangan dalam 20 seri MotoGP 2022, yang seluruhnya dipersembahkan Quartararo. Pada prosesnya, rider Prancis itu harus puas finis runner-up di bawah Francesco Bagnaia (Ducati) dengan selisih 17 poin. Sementara itu Morbidelli menjalani musim untuk dilupakan setelah finis di urutan 19 dengan hanya sekali finis 10 besar.\r\n\r\nKedua pebalap itu memungkinkan berpisah di akhir musim ini. Pasalnya, Fabio Quartararo masih terikat kontrak dengan Yamaha sampai 2024, sedangkan kontrak Morbidelli akan habis pada tahun ini.\r\n\r\nSetelah Yamaha, Gresini akan menjadi tim MotoGP kedua yang melakukan peluncuran, yaitu pada 21 Januari. Sang juara Ducati menyusul pada dua hari berselang di Italia.', 'Y', 'Y', 'Y', 13, '7e2dab5555a765a8d75f254415dcd6ac.jpeg', 'Y', '2023-02-01'),
(104, 'Turnamen Basket ABL Kembali Digelar, Louvre Jadi Wakil Indonesia', 'turnamen-basket-abl-kembali-digelar-louvre-jadi-wakil-indonesia', 'Sijaupdate.com- Turnamen bola basket antarklub Asia Tenggara plus Asia Timur, ASEAN Basketball League (ABL) 2023, akan kembali bergulir. Kali ini Indonesia diwakili Louvre.\r\nGelaran ini akan diputar lagi setelah rehat selama hampir dua setengah tahun. Edisi 2019/2020 sedianya menjadi yang terakhir kali dihelat sebelum rehat karena situasi pandemi COVID-19, tapi berhenti di tengah jalan.\r\n\r\nDengan begitu 2018/2019 menjadi edisi terakhir yang digelar secara penuh. Saat itu wakil Indonesia CLS Knights Indonesia yang keluar sebagai juaranya.\r\n\r\nPelatih CLS saat juara ABL Brian Rowson dipastikan akan menangani Louvre untuk menangani tim. Beberapa asisten dari luar negeri juga bakal dipakai membantu Rowson di Louvre.\r\n\r\nABL edisi kali ini bertajuk Invitational dengan Singapura akan menjadi tuan rumah, mulai 2 Januari 2023. Total ada delapan peserta dari delapan negara berbeda yang ikut serta.\r\n\r\n\r\nSelain Louvre, peserta lainnya adalah Cooly Bangkok Tigers (Thailand), Hong Kong Eastern, Macau Black Bears, NS Matrix (Malaysia), Saigon Heat (Vietnam), Singapore Slingers (Singapura) dan Zamboanga Valientes (Filipina).\r\n\r\nRencananya bakal ada empat seri sebelum babak semifinal dan final. Sementara lokasi babak puncak masih belum diumumkan. Indonesia juga kebagian menggelar ABL 2023 yakni di Hi-Test Arena pada 12 sampai 18 Januari 2023.\r\n\r\nAdapun mengenai regulasi pemain, setiap tim peserta diperbolehkan memakai tiga pemain asing dengan satu pemain keturunan atau heritage. Louvre awalnya berniat memakai Jamarr Andre Johnson sebagai pemain heritage. Sayangnya tim-tim peserta menolak.\r\n\r\nNamun demikian Louvre tetap akan menggunakan jasa Jamarr. Tapi karena penolakan dari peserta lain, Jamarr akan berstatus sebagai pemain asing.', 'Y', 'Y', 'Y', 13, '5f679c624cc30ab4cc3ee1e7cc4058f4.jpeg', 'Y', '2023-02-01'),
(105, 'Thailand Masters 2023: Indonesia Siap Tempur di Bangkok', 'thailand-masters-2023-indonesia-siap-tempur-di-bangkok', 'Sijaupdate.com- Thailand Masters 2023 akan digelar pada 31 Januari sampai 5 Februari. Para pebulutangkis Indonesia sudah ada yang tiba di Bangkok dan siap tempur!\r\nSkuad Merah-Putih mengirimkan 23 pemain ke turnamen level BWF World Tour Super 300 itu. Sang juara ganda putra Daihatsu Indonesia Masters 2023 di Jakarta kemarin, Leo Rolly Carnando/Daniel Marthin makin menambah kekuatan.\r\n\r\nLeo/Daniel bersama kepala pelatih ganda putra Herry Iman Pierngadi menyusul terbang ke Bangkok pada Senin (30/1) ini. Sementara pemain-pemain yang lain sudah bertolak lebih dahulu dari Jakarta, Minggu (29/1) kemarin.\r\n\r\n\"Semua pemain, pelatih, dan tim pendukung dalam kondisi prima. Kami siap tempur untuk menghadapi turnamen Thailand Masters ini,\" kata manajer tim Prasetyo Restu Basuki dari keterangan Tim Humas dan Media PBSI.\r\n\r\nDijelaskan Prasetyo, demi menjaga kondisi, pemain memang diistirahatkan pada hari kedatangan di Bangkok. Pemain baru menjalani latihan di hari Senin (30/1) ini. Pada pagi hari, sekitar sejam pemain berlatih gim di practice hall di kompleks Nimibutr Stadium.\r\n\r\n\"Baru pada sore nanti, tim Indonesia bisa berlatih di main hall Nimibutr Stadium. Ada lima lapangan yang disediakan oleh panitia. Masing-masing sektor bisa berlatih selama satu jam,\" tutur Prasetyo, yang juga merangkap sebagai pelatih ganda putri.\r\n\r\nPrasetyo sangat berharap pemain bisa memaksimalkan sesi latihan di arena yang bakal menjadi tempat pertandingan turnamen berhadiah total 210 ribu dolar AS tersebut. Tak hanya berlatih teknik, tetapi pemain bisa sekaligus mulai beradaptasi dengan arah angin, tata cahaya, dan karakter shuttlecock yang digunakan.\r\n\r\nBicara tentang target yang hendak dicapai, Prasetyo menyebut agar pemain bisa bermain bagus dan fokus menjalani babak demi babak lebih dulu. Para pemain tentu ingin memberikan hasil yang terbaik.\r\n\r\nMeski begitu, dirinya sangat mengharapkan ada gelar juara yang bisa direbut. Pasangan ganda putra Leo/Daniel dan Muhammad Shohibul Fikri/Bagas Maulana, serta ganda campuran Rehan Naufal Kusharjanto/Lisa Ayu Kusumawati digadang-gadang bisa kembali berjaya.\r\n\r\n\"Semoga harapannya ada gelar juara yang bisa dibawa pulang ke Tanah Air. Semoga pula semua pemain bisa tampil semaksimal mungkin dan selalu fokus dari babak demi babak lebih dulu,\" ujar Prasetyo.', 'Y', 'Y', 'Y', 13, '4963803de3a653aa9b7d95792f057255.jpeg', 'Y', '2023-02-01'),
(107, 'Gigi Gelar Konser Rayakan 29 Tahun Berkarya, Harga Tiket Mulai Rp 500 Ribu', 'gigi-gelar-konser-rayakan-29-tahun-berkarya-harga-tiket-mulai-rp-500-ribu', 'Sijaupdate.com- Grup band legendaris, Gigi siap menggelar konser. Bertajuk \'Gigi - Free Your Soul Live in Jakarta\', acara ini dihelat di Puri Agung Convention Center, Grand Sahid Jaya, Jakarta, Jumat (17/3/2023).\r\n\r\nKonser Gigi kali ini sekaligus menjadi perayaan 29 tahun berkarya. Armand Maulana cs pun tidak mau setengah-setengah dalam menyuguhkan penampilan spesial mereka.\r\n\r\n\"Durasinya akan 2 jam, berbeda dari festival,\" kata Armand Maulana saat konferensi pers belum lama ini.\r\n\r\nDalam aksi panggungnya nanti, band yang hits lewat lagu 11 Januari itu akan mengenang kembali perjalanan karier selama ini.\r\n\r\nTiket termurah ada di silver, Rp 500 ribu. Kategori ini adalah standing bagi pemegang tiket.\r\n\r\nSementara yang termahal, diamond berada di harga Rp 750 ribu. Berbeda dari kelas sebelumnya, kategori ini penonton akan mendapat nomor kursi.\r\n\r\n\"Tentu yang spesial, Gigi akan mengeksplor apa yang terjadi selama 29 tahun nanti di panggung,\" imbuh sang vokalis.\r\n\r\nGusti Hendy, drummer Gigi juga memberikan bocoran bahwa lagu-lagu pada konser nanti akan bervariasi. \"akan ada nuansa 90\'an hingga 2000-an,\" tuturnya.\r\n\r\nBagi penggemar Gigi yang mau menyaksikan konser ini, Danurwenda Karya Utama sebagai promotor menawarkan dua kategori tiket. Penjualannya pun akan berlangsung mulai 1 Februari melalui platform tiket online.', 'N', 'N', 'Y', 14, '5f50c491fac4800de78a3da894e8e19b.jpeg', 'Y', '2023-02-01'),
(108, 'Mawar de Jongh Hampir Menyerah Mainkan Peran Marni di Film Para Betina Pengikut Iblis', 'mawar-de-jongh-hampir-menyerah-mainkan-peran-marni-di-film-para-betina-pengikut-iblis', 'Sijaupdate.com- Mawar de Jongh mendapat peran tak lazim di film Para Betina Pengikut Iblis. Artis 21 tahun ini memainkan tokoh Sumi yang berjualan gulai dari daging manusia demi bertahan hidup.\r\n\r\nBercerita tentang peran Sumi, Mawar de Jongh menyebut tugas berjualan gulai daging manusia sempat membuat batinnya bergejolak.\r\n\r\n\"Karakter Sumi ini saja sudah jadi tantangan berat,\" kata Mawar de Jongh di kawasan Duren Tiga, Jakarta Selatan, Jumat (27/1/2023).\r\n\r\nAntusias di awal, Mawar de Jongh sempat tak ingin berperan lagi sebagai Sumi setelah tahu kesehariannya.\r\n\r\n\"Saya sempat enggak yakin bisa peranin karakter ini,\" tutur Mawar de Jongh.\r\n\r\nSosok sutradara Rako Prijanto lah yang kemudian membuat Mawar de Jongh yakin melanjutkan tugasnya sebagai Sumi.\r\n\r\n\"Mas Rako ini bisa membantu saya bertukar cerita tentang kendala memainkan karakter Sumi ini,\" jelas Mawar de Jongh.\r\n\r\nKeinginan kuat untuk berkembang juga jadi alasan lain Mawar de Jongh bertahan di film tersebut.\r\n\r\n\"Rasa keingintahuan saya di dunia seni peran yang membawa saya sampai sini,\" ucap Mawar de Jongh.\r\n\r\nPara Betina Pengikut Iblis bercerita tentang tiga orang perempuan yang bersekongkol dengan iblis demi mengejar kepentingan duniawi. \r\n\r\n\"Saya membuat film ini terilhami dari tiga ayat di Alquran yaitu An-Nas, Ali Imran ayat 17 dan Al-Humazah. Jadi tiga perempuan ini mencerminkan dari ayat itu,\" ungkap Rako Prijanto.\r\n\r\n\"Bagaimana bisikan iblis mengganggu kita, bagaimana kita harus sabar dan taat sebagai makhluk Allah, bagaimana ucapan-ucapan kedengkian yang datang dari hati bisa menghancurkan kita semua,\" kata Rako menyambung.', 'Y', 'N', 'Y', 14, 'f0ff5f04557fac8d59e56e18b02bd72d.jpeg', 'Y', '2023-02-01'),
(109, 'Kiky Saputri Cerita Pengalaman Malam Pertamanya: Aku Dihajar Bertubi-tubi Tanpa Perlawanan', 'kiky-saputri-cerita-pengalaman-malam-pertamanya-aku-dihajar-bertubi-tubi-tanpa-perlawanan', 'Sijaupdate.com- Setelah resmi menikah pada Sabtu (28/1/2023), tak sedikit yang penasaran dengan pengalaman malam pertama Kiky Saputri dengan suaminya, M. Khairi.\r\n\r\nTak terkecuali Mpok Alpa dan Raffi Ahmad yang penasaran hingga menelepon Kiky Saputri untuk kepo malam pertama mereka.\r\n\r\nKiky Saputri sempat terlihat malu -malu dan terkejut ditanya soal pengalaman malam pertamanya dengan M. Khairi.\r\n\r\nKiky Saputri mengaku tidak melawan ketika dihajar bertubi-tubi selama malam pertama dengan suaminya, Khairi.\r\n\r\n\r\nSebelumnya, Kiky Saputri juga sempat curhat sudah dua kali keramas setelah sehari menikah dengan Khairi.\r\n\r\n\"Sehari dua kali keramas, gini banget ya jadi penganten, hehehe,\" kata Kiky Saputri dalam Instagram Storynya.\r\n\"Aku dihajar bertubi-tubi tanpa perlawanan,\" ujar Kiky Saputri yang disahut gelak tawa penonton.', 'Y', 'Y', 'Y', 14, '1e80ef0db98683be4875aac32614e08c.jpeg', 'Y', '2023-02-01'),
(110, 'Bunda Corla Resmi Dilaporkan ke Polisi, Akun Farhat Abbas di Geruduk Netizen', 'bunda-corla-resmi-dilaporkan-ke-polisi-akun-farhat-abbas-di-geruduk-netizen', 'Sijaupdate.com- Setelah disomasi selebgram yang sedang naik daun, Bunda Corla dilaporkan ke Polres Metro Jakarta Selatan oleh pengacara Farhat Abbas, Senin (30/1) siang. Mantan suami Nia Daniaty itu melaporkan Bunda Corla karena dianggap telah melakukan sesuatu tidak senonoh.\r\n\r\nKabar tersebut diketahui dari unggahan Farhat Abbas di Insta Stories akun Instagram miliknya, @farhatabbasofficial. Dalam unggahannya, pengacara kontroversi itu memajang foto sedang berada di kantor polisi bersama petugas. \r\n\r\nDalam foto tersebut Farhat Abbas juga menuliskan kata-kata sindiran diduga ditujukan untuk pemilik nama Cynthia Corla Pricillia yang dituding melakukan pelanggaran UU ITE.\r\n\r\n\"Mamang Cor Resmi Kami Laporkan UU ITE, 30 Januari 2023,” tulisnya. \r\n\r\nUnggahan Farhat Abbas itu pun viral setelah diunggah ulang oleh beberapa akun gosip. Netizen menggeruduk akun instagram miliknya hingga ramai-ramai melaporkan ke Instagram.\r\n\r\nBanyak netizen yang tak setuju dengan apa yang dilakukan oleh Farhat Abbas hingga membuat warganet ramai-ramai menghujatnya.\r\n\r\n“Inilah penting nya imunisasi sejak dini. KWKWKKW yaa Allah pakk, ngapain urus hidup orang, Uda yang paling bener lu? Apa karena bapak ga laku jadi pengacara?? KWKWKW, urus keluarga masing masing ya pak, duduk manis.. udah tua kan? Kwkwkwkwk,” tulis netizen di unggahan terbaru instagram miliknya. \r\n\r\n“Ya elah bucor kenal kaga sama elu elu cari kesibukan sendiri lapor laporin bucor..ya allah mas tobat tobat jangan ganggu kehidupan orang..serem banget khidupan kau mas ngusik org mulu,\" ungkap netizen lainnya.\r\n\r\n“Duitnya udah engga ada jadi dia cari sensasi kali yaa .. bunda corla bunda gw bandit mah gakan terkecohh sm yg beginiaaann,\" kata netizen.\r\n\r\nSebelumnya, pengacara tersebut juga melayangkan somasi terhadap Bunda Corla. Bahkan, Farhat Abbas memberikan waktu 2x24 jam untuk Bunda Corla mau merespon somasinya tersebut.\r\n\r\n“Kepada mang Corla, ya somasi dari tanggal 24, resmi ya, kalau kemarin kan hanya pernyataan saya dari Instagram, tapi kali ini adalah resmi,\" ujar Farhat Abbas.\r\n\r\n\"Menyangkut UU pornografi dan UU ITE, Setelah kami kumpulkan bukti-bukti yang menyangkut adanya kegiatan pornografi gerak, kata-kata, suara, gambar, pakaian, yang kita anggap melanggar UU pornografi,\"tegas Farhat Abbas.', 'Y', 'Y', 'Y', 14, '7454e084bd4bf70803599afbf39faf35.jpeg', 'Y', '2023-02-01'),
(111, 'Ruben Onsu Ancam Penjarakan Penyebar Berita Negatif Betrand Peto', 'ruben-onsu-ancam-penjarakan-penyebar-berita-negatif-betrand-peto', 'Sijaupdate.com- Betrand Peto Putra Onsu terus-menerus menjadi sasaran para perundung. Tidak tinggal diam, melalui surat terbuka yang diposting di Instagramnya, Ruben Onsu memberi peringatan kepada oknum-oknum tak bertanggung jawab untuk segera menghentikan pembuatan berita negatif tentang Betrand di berbagai platform media sosial atau akan ia seret ke jalur hukum.\r\n\r\nBeberapa waktu belakangan, beredar foto dan video Betrand yang diedit kreator konten bersama istri Ruben Onsu, Sarwendah. Betrand yang telah beranjak remaja dinarasikan seolah memiliki kedekatan khusus dengan Sarwendah. Betrand sendiri merupakan anak angkat Ruben yang kini menjelma menjadi artis kondang. \r\n\r\n\"Kami, selaku Kuasa Hukum dari PT. Media Bens Abadi dengan ini menyampaikan peringatan terbuka sehubungan dengan terdapat banyaknya unggahan pada sosial media dan platform video online atas artis di bawah naungan manajemen klien kami PT. Media Bens Abadi, yakni Betrand Putra Onsu,\" bunyi pembuka surat terbuka yang diunggah pada Senin (30/1).\r\n\r\n\"Adapun unggahan sebagaimana dimaksud adalah unggahan yang mengandung informasi yang dibuat dengan narasi tidak sesuai fakta maupun narasi-narasi yang termasuk opini tidak baik yang diduga dapat menyebabkan pencemaran nama baik dari Betrand Putra Onsu,\" sambungnya.\r\n\r\n\"Melalui surat peringatan terbuka ini, kami dari pihak kuasa hukum PT. Media Bens Abadi memberikan peringatan terbuka kepada seluruh oknum yang mengunggah dan menyebarluaskan unggahan tersebut agar segera menghapus dan tidak mengunggah kembali informasi yang tidak berdasar dan sesuai fakta tersebut atas artis yang berada di bawah naungan manajemen kami yakni Betrand Putra Onsu dan artis-artis lainnya,\" tambahnya lagi. \r\n\r\nRuben dan timnya sekali lagi menegaskan kepada siapa pun agar menghapus foto, video, atau men-takedown berita bernada negatif tentang Betrand Peto. Apabila semenjak surat itu diterbitkan masih ditemukan akun yang melakukan hal tersebut, Ruben dan tim tidak ragu untuk menyeretnya ke jalur hukum, tentunya sesuai ketentuan hukum yang berlaku di Indonesia. \r\n\r\nLangkah tegas Ruben dan manajemen mendapat dukungan dari para netizen. Menurut netizen, efek jera diperlukan agar tak ada lagi orang yang melakukan aksi serupa, mengedit foto atau video dengan tujuan mencemarkan nama baik. \r\n\r\n\"Mereka yang bikin video itu enggak ngotak. Yang nyebarluaskan juga enggak punya kerjaan. Kasih efek jera Koh Ruben. Maju terus buat The Onsu Family,\" dukung netizen. \"Satu bersih aja semua oknum yang enggak bertanggung jawab biar kapok,\" tegas netizen lain.', 'N', 'N', 'Y', 14, '34c3809cc7542c7dac5b8b9bb09bcecb.jpeg', 'Y', '2023-02-01'),
(112, 'Mahasiswa Doktoral UI Teliti Sebab Mahasiswa Enggan Lapor Kecurangan, Ada 4 Motif', 'mahasiswa-doktoral-ui-teliti-sebab-mahasiswa-enggan-lapor-kecurangan-ada-4-motif', 'Sijaupdate.com- Kecurangan akademik di seluruh jenjang pendidikan tentunya adalah hal yang mengkhawatirkan. Namun, hal ini menjadi lebih mengkhawatirkan jika terjadi perguruan tinggi jenjang sarjana karena lulusannya akan memasuki dunia kerja.\r\nPada sebuah kecurangan akademik, tak jarang ada orang yang mengetahuinya tetapi memilih diam tidak melapor kepada dosen atau orang lain yang berwenang.\r\n\r\nSituasi semacam itu memunculkan ide untuk Anna Armeini Rangkuti, mahasiswa doktoral Fakultas Psikologi Universitas Indonesia (UI) untuk menelitinya. Pasalnya, pelaporan oleh mahasiswa saksi bisa mencegah dan mengurangi terjadinya kecurangan.\r\n\r\nMelalui disertasi doktoralnya, Anna mengangkat isu tersebut. Dia menilai hal ini perlu dikaji karena ada banyak mahasiswa yang menyaksikan kecurangan, tetapi tidak melaporkan.\r\n\r\n\"Kedua, adalah sensitivitas etis saksi kecurangan akademik yang mengabaikan dan menganggap peristiwa kecurangan adalah hal yang biasa akan terkikis secara bertahap,\" imbuhnya, dikutip dari rilis di laman UI.\r\n\r\nPengabaian atas kecurangan menurut Anna dapat membuat saksi menganggap bahwa hal ini bisa diterima, meski bisa makin parah dari waktu ke waktu.\r\n\r\nAnna mengidentifikasi motif yang mendasari diamnya mahasiswa yang mengetahui atau menyaksikan kecurangan akademik. Dia menyusun analisisnya dalam penelitian berjudul \"Mekanisme Pelemahan Silence Mahasiswa Saksi Kecurangan Melalui Peran Mediasi Seriousness of Academic Cheating dalam Perspektif Pengambilan Keputusan Etis\".\r\n\r\nPada penelitiannya, Anna juga menerangkan mekanisme pelemahan silence (diam) berdasarkan perspektif pengambilan keputusan etis.\r\n\r\n4 Motif Mahasiswa Enggan Lapor Kecurangan\r\nPenelitian Anna berhasil mengidentifikasi empat motif utama diamnya mahasiswa saksi kecurangan akademik. Keempat motif itu adalah acquiescent atau karena merasa tidak berdaya mengubah situasi, prososial atau karena memiliki motif altruistik untuk membantu pelaku/menjaga nama baik institusi, oportunistik atau karena motif kepentingan pribadi dan tidak ingin repot dengan prosedur pelaporan kecurangan, serta defensif atau karena merasa takut dengan konsekuensi yang dihadapi apabila melapor.\r\n\r\nPada penelitian ini terungkap, motif proporsional dan defensif adalah yang paling dominan ketimbang dua motif lainnya.\r\n\r\nMotif silence prososial dapat diartikan sebagai sisi empati mahasiswa yang menyaksikan kecurangan. Mahasiswa tersebut berempati kepada pelaku yang mungkin akan kesulitan apabila kecurangannya dilaporkan.\r\n\r\nDi samping itu, motif silence prososial juga bisa dilihat dari sisi nilai budaya masyarakat kolektif di Indonesia. Kehidupan dalam budaya kolektif lebih mengutamakan keharmonisan dan solidaritas.\r\n\r\nBahkan, salah satu indikasi kesejahteraan psikologis individu dalam masyarakat kolektif adalah sikap dan perilaku yang mengutamakan kepentingan orang lain. Dalam hal ini tak terkecuali menolong orang lain supaya tidak kesulitan di berbagai sisi kehidupan.\r\n\r\nSementara, motif silence defensif ditunjukkan dengan rasa takut akan disingkirkan dari pergaulan serta akan dimusuhi mahasiswa lain jika melaporkan kecurangan akademik.\r\n\r\nKontribusi untuk Pihak-pihak di Pendidikan Tinggi\r\n\r\nPenelitian dosen Fakultas Pendidikan Psikologi Universitas Negeri Jakarta (UNJ) ini mempunyai kontribusi praktis untuk berbagai pihak yang berkaitan dengan pendidikan tinggi.\r\n\r\nPertama, peraturan tentang kecurangan akademik perlu mencantumkan tanggung jawab peran mahasiswa saksi secara eksplisit. Kedua, tersedianya sarana melapor yang memadai, aman, dan menjaga kerahasiaan identitas mahasiswa saksi kecurangan.\r\n\r\nKetiga, standardisasi regulasi yang berhubungan dengan kecurangan akademik di kelas-kelas perkuliahan serta antarfakultas. Standardisasi ini dimaksudkan supaya kesadaran kecurangan akademik, keseriusan kecurangan akademik, dan pelaporan semakin menguat dan memperbes…', 'Y', 'Y', 'Y', 9, '867dca6f0cc808cbcaa640790cfda655.jpeg', 'Y', '2023-02-01'),
(113, '3 Tips Peraih IPK Tertinggi ITB Seimbangkan Bidang Akademik dan Nonakademik', '3-tips-peraih-ipk-tertinggi-itb-seimbangkan-bidang-akademik-dan-nonakademik', 'Sijaupdate.com- Menyeimbangkan akademik dan nonakademik bukan perkara mudah bagi mahasiswa. Namun, Vinka Amalia Hasta Barata berhasil lulus dari Institut Teknologi Bandung (ITB) dengan prestasi di kedua bidang tersebut.\r\nMahasiswa Jurusan Manajemen di Sekolah Bisnis dan Manajemen (SBM) ITB ini diketahui berhasil meraih IPK tertinggi, sebesar 3.98 dari skala 4.00 dalam perayaan Wisuda Oktober ITB 2022 kemarin. Tak hanya kantongi IPK tertinggi, Vinka juga berhasil menorehkan prestasi yang sangat baik pula dalam kegiatan nonakademik.\r\n\r\nDeretan pencapaiannya antara lain tergabung ke dalam Badan Pengurus Keluarga Mahasiswa Manajemen (KMM) ITB sebagai Vice Manager Education sejak tahun 2021, Dirjen Akuntansi di Keluarga Mahasiswa (KM) ITB tahun 2021/2022, Research Assistant SBM ITB untuk joint research dengan Griffith University Australia, dan Business Development Staff di Techno Entrepreneur Club (TEC) ITB.\r\n\r\nTips Seimbangkan Kegiatan Akademik dan Nonakademik\r\n1. Atmosfer Akademik yang Mendukung\r\nVinka mengakui, atmosfer akademik ITB-lah yang mendukung Vinka untuk meraih prestasi gemilang. Khususnya di SBM ITB, atmosfer pembelajaran yang dibangun secara kondusif dan kompetitif sangat mendukung ia dan mahasiswa SBM lainnya untuk berkembang.\r\n\r\nIklim kolaborasi yang diaplikasikan secara masif dalam setiap kurikulum mata kuliah pun berhasil menumbuhkan jiwa kerja sama yang sangat baik bagi seluruh mahasiswanya.\r\n\r\n\"Pada setiap semesternya, mahasiswa selalu disisipi dengan mata kuliah praktik yang berbentuk proyek kelompok. Mata kuliah praktik ini bertujuan untuk mengaplikasikan teori-teori yang telah didapatkan di kelas dan juga melatih soft skill mahasiswa,\" ungkapnya dalam laman resmi ITB, dikutip Selasa (1/11/2022).\r\n\r\n2. Tahu Batas, Kapasitas, dan Diri Sendiri\r\nSelain kondisi lingkungan akademik yang mendukung, menerapkan prinsip, \'Know Your Boundaries, Know Your Capacities, and Know Yourself\" atau \'Tahu Batas, Kapasitas, dan Diri Sendiri\' merupakan strategi khusus yang Vinka terapkan dalam menjalani pendidikannya di ITB.\r\n\r\nIa menyebutkan, dalam menentukan setiap pilihan kegiatan yang akan ia ikuti, Vinka selalu mempertimbangkan biaya dan keuntungan yang akan didapatkan ke depannya. Ia mengklaim bahwa dirinya adalah tipe mahasiswa yang tidak akan FOMO (Fear of Missing Out) atau ikut-ikutan mahasiswa yang lain saat memilih kegiatan.\r\n\r\n\"Aku sendiri selalu berusaha mempertimbangkan cost benefit setiap pilihan kegiatan yang aku ambil. Terkadang ada beberapa mahasiswa yang FOMO dan berusaha ikut-ikutan teman dengan aktif di banyak kegiatan, tetapi aku tipe yang sangat hati-hati dalam memilih kegiatan sehingga aku bisa memaksimalkan potensi yang aku punya,\" ujarnya.\r\n\r\nSama seperti mahasiswa lainnya, perjalanan kuliah Vinka sering mendapatkan tantangan. Ia menceritakan bahwa pada fase awal perkuliahan, dirinya pernah mengalami kesulitan untuk membayar biaya UKT. Bahkan pengajuan beasiswa yang Vinka lakukan kerap mengalami kegagalan.\r\n\r\n\"Tapi, aku tidak menyerah dan akhirnya bisa mendapatkan potongan biaya kuliah itu sejak tahun kedua dan semakin ringan di tahun ketiga. Aku juga bersyukur, pada akhirnya bisa mendapat beasiswa unggulan dari Bank Indonesia pada tahun ke-2, dan bahkan tugas akhirku juga mendapatkan pendanaan dari BI Institute,\" jelasnya.\r\n\r\n3. Hindari Memikirkan Hal Tidak Penting\r\nTerakhir, Vinka berpesan bahwa untuk mendapatkan prestasi yang gemilang dalam hal akademik maupun nonakademik, kunci lainnya yang bisa dilakukan adalah dengan menghindari memikirkan hal-hal yang tidak penting.\r\n\r\nIa menyarankan untuk selalu fokus kepada hal-hal yang berarti dan berada pada lingkup yang bisa dikontrol oleh diri sendiri. Selain itu, Vinka juga mengatakan bahwa seorang mahasiswa harus selalu bekerja dengan cerdas agar proses yang dilakukan itu bisa tetap efektif dan efisien.', 'Y', 'N', 'Y', 9, '6a82837f70d0d576f79d51947be3b6ec.jpeg', 'Y', '2023-02-01'),
(114, 'Iluni UI dan Mahasiswa SKSG UI Telisik Strategi Ketahanan Partai Politik', 'iluni-ui-dan-mahasiswa-sksg-ui-telisik-strategi-ketahanan-partai-politik', 'Sijaupdate.com- Partai politik adalah inti dari demokrasi, itu sebabnya Clinton Rossiter berpendapat bahwa tidak ada Amerika tanpa demokrasi, tidak ada demokrasi tanpa politik, dan tidak ada politik tanpa partai. Dalam konteks Indonesia, Executive Director, Indikator Politik Indonesia, Burhanuddin Muhtadi, M.A., Ph.D., menilai bahwa partai politik juga bisa menjadi bagian dari masalah jika partai masih kurang kredibel, perbedaan ideologi antarpartai kurang terlihat, kelembagaan partai lemah, dan banyak partai terjerat kasus korupsi. Padahal, demokrasi bangsa akan tercapai jika partai menjalankan fungsinya dengan benar.\r\n\r\nUntuk membahas persoalan ini, Ikatan Alumni (ILUNI) Sekolah Pascasarjana Universitas Indonesia (UI) bekerja sama dengan ILUNI UI dan Program Studi S3 Sekolah Kajian Stratejik dan Global (SKSG) UI mengadakan Seminar Nasional bertajuk “Pelembagaan Partai dan Kepemimpinan Strategis Nasional”, pada Kamis (26/1), di Hotel Savoy Homann, Bandung. Pada kesempatan itu, Mahasiswa Program Doktoral SKSG UI, Dr. Ir. Hasto Kristiyanto, M.M., membahas perlunya evaluasi untuk melihat apakah kerja yang dilakukan partai telah sesuai dengan kebutuhan masyarakat.\r\n\r\n“Masyarakat memberikan respons positif sekaligus kritik terkait fungsi intermediasi partai dalam membangun komunikasi politik serta peran agregasi kepentingan rakyat dalam membuat kebijakan publik. Itu ternyata masih sangat kurang. Namun, masyarakat juga memberikan potret bahwa kemampuan partai dalam menyesuaikan perubahan dipersepsikan sangat penting, baru kemudian tentang kepemimpinan, ideologi, dan kultur organisasi partai. Itu adalah empat hal yang dinilai sangat penting dalam pelembagaan partai,” kata Dr. Hasto yang juga merupakan Sekretaris Jenderal Partai Demokrasi Indonesia Perjuangan (PDIP).\r\n\r\nUntuk keberlanjutan suatu organisasi, diperlukan ketahanan jangka panjang. Partai harus memiliki ketangguhan, keuletan, dan sikap dinamis dalam menghadapi VUCA (volatility, uncertainty, complexity, ambiguity) ataupun ATHG (ancaman, tantangan, hambatan, gangguan). Langkah-langkah untuk menumbuhkan ketahanan partai ini dibahas oleh beberapa narasumber, antara lain Ketua Prodi S3 SKSG UI, Dr. Drs. A. Hanief Saha Ghafur, M.Si.; Guru Besar Fakultas Hukum UI, Prof. Dr. Satya Arinanto, S.H., M.H.; Guru Besar Ilmu Politik dan Keamanan Universitas Padjadjaran, Prof. Muradi, M.A., Ph.D.; dan Kepala Staf Komando Operasi Udara Nasional, Marsekal Muda TNI Jorry Soleman Koloay, S.I.P.\r\n\r\nAda dua dimensi yang menghubungkan pemilih dan partai politik, yaitu identifikasi diri dengan partai (Party ID) dan evaluasi massa pemilih atas fungsi intermediasi partai (dimensi rasional). Party ID merupakan komponen psikologis yang memberikan dukungan terhadap partai dan sistem kepartaian, yang pada akhirnya memperkuat demokrasi. Sementara itu, intermediasi partai adalah evaluasi massa pemilih terhadap partai politik apakah telah berfungsi menghubungkan kepentingan massa dengan kebijakan pemerintah.\r\n\r\nMenurut Prof. Muradi, yang menjadi masalah dari partai adalah selama 20 tahun partai di Indonesia gagal karena tidak bisa memperkuat Party ID. Selama ini, Party ID hanya berfokus pada tiga hal, yaitu pola historis, struktur ekonomi, dan strata sosial. Padahal, sebagian besar warga memilih partai berdasarkan figur yang ada di partai tersebut. Akan tetapi, jika hanya mengandalkan figur, partai akan lenyap jika figur yang disegani masyarakat sudah tidak lagi berada di partai. Oleh karena itu, partai juga harus memiliki ideologi.\r\n\r\n“Ada dua unsur penting dalam proses partai politik, yaitu ideologi dan figur. Jika kita hanya berbicara tentang figur saja, kita akan kehilangan gagasan dalam konteks membangun basis politik. Padahal, ketika sebuah peradaban baru muncul, partai membutuhkan leader. Karena itu, diperlukan Penta-Polics, yaitu lima unsur penting da…', 'Y', 'N', 'Y', 9, 'ba3a85b5024bf112a834f327f71eac5d.jpeg', 'Y', '2023-02-01'),
(115, 'Raih Doktor Usai Teliti Geopark Nasional Karangsambung-Karangbolong', 'raih-doktor-usai-teliti-geopark-nasional-karangsambung-karangbolong', 'Sijaupdate.com- Peneliti Ahli Utama, Pusat Riset Sumberdaya Geologi, BRIN, Ir. Chusni Ansori, M.T., dinyatakan lulus program doktor Teknik Geologi UGM. Ia dinyatakan lulus setelah berhasil menjalani ujian terbuka di Departemen Teknik Geologi, Fakultas Teknik UGM, Jumat (27/1).\r\n\r\nDi hadapan tim penguji, ia berhasil mempertahankan disertasi berjudul Analisis Faktor Litologi dan Bentanglahan Terhadap Sebaran Keragaman Situs Budaya Megalitikum –Kolonial, Pada Kawasan Taman Bumi (Geoprak) Karangsambung – Karangbolong Dan Sekitarnya, Kabupaten Kebumen, Provinsi Jawa Tengah.\r\n\r\n“Terdapat tiga pilar utama dalam geopark berupa keragaman geologi, biologi dan budaya dengan tujuan untuk konservasi, edukasi dan pengembangan ekonomi secara berkelanjutan. Keanekaragaman biologi dan keragaman budaya ini bukan sesuatu yang berdiri sendiri namun mempunyai keterkaitan dengan keragaman geologinya,\" ujar Chusni Ansori.\r\n\r\nDia menyampaikan sejak 2018 di Kabupaten Kebumen telah terbentuk Geopark Nasional Karangsambung-Karangbolong yang akan dikembangkan menjadi Geopark Global UNESCO. Oleh karena itu, penelitian inter disiplin yang ia lakukan untuk mengetahui pengaruh 7 variabel geologi terhadap sebaran keragaman situs budaya tanjible pada era Megalitikum, Hindu-Budha, Islam dan Kolonial.\r\n\r\nKeragaman geologi daerah penelitian, disebutnya, telah menghasilkan keragaman budaya dari Era Megalitikum hingga Kolonial. Pengaruh litologi terhadap pembentukan budaya kawasan pada Era Megalitikum sebesar 2,3 persen, Hidu-Budha 11,3  persen, Islam 2,9 persen, dan Kolonial 2,6 persen.\r\n\r\n“Endapan alluvial mempunyai persentase sebaran situs paling banyak pada setiap era. Artefak batuan beku yang bersumber dari Formasi Halang meliputi M1, M2, M3, M4, HB2, HB5, HB7, HB9, dan HB12. Sementara artefak dari Formasi Gabon meliputi M5, M8, M9, M10, HB8, HB11, K32, dan K75. Artefak M6 dari F. Bulukuning. Keramik HB6B, HB6C bersumber dari luar Kebumen. Tembikar atau genten atau bata HB39, K39, K50, K58, I21 dari Formasi Halang,\" terangnya.\r\n\r\nIa menyimpulkan pada era Megalitikum warisan budaya lumpang batu yang berfungsi sebagai alat pengolahan pertanian tersebar pada endapan alluvial, disekitar pasir besi, ketinggian &lt; 50 m, kelerengan &lt; 7 %, bentang lahan marine (M), jarak sungai &lt; 750 m, daerah akuifer produktif, dan area yang berkorelasi baik – sangat baik. Pada era Hindu-Buddha sebagian besar berupa tempat atau sarana ibadah berada pada endapan alluvial.\r\n\r\nPada era Islam makam atau makom berada pada endapan alluvial. Sedangkan pada era Kolonial situs yang berfungsi untuk ekonomi, pemerintahan, sekolahan, kesehatan, dan pertahanan mengelompok mengikuti pola sebaran situs pemerintahan di seputar Kebumen, Karanganyar, Gombong, Kutowinangun- Prembun.', 'N', 'Y', 'Y', 9, 'd7b02f4a08d794111b08d123f117d11d.jpeg', 'Y', '2023-02-01');
INSERT INTO `posting` (`id`, `title`, `seo_title`, `content`, `featured`, `choice`, `thread`, `id_category`, `photo`, `is_active`, `date`) VALUES
(116, 'Kenapa Jalur Prestasi SNBP Pakai Nilai Rata-rata Semua Mata Pelajaran?', 'kenapa-jalur-prestasi-snbp-pakai-nilai-rata-rata-semua-mata-pelajaran', 'Sijaupdate.com- Seleksi Nasional Berdasarkan Prestasi (SNBP) merupakan jalur prestasi masuk perguruan tinggi (PTN) 2023 secara nasional. SNBP menggunakan nilai rata-rata semua mata pelajaran dalam salah satu komponen seleksi, bukan nilai mata pelajaran tertentu saja seperti Seleksi Nasional Masuk PTN (SNMPTN) tahun lalu. Kenapa, ya?\r\nSebelumnya, jalur SNMPTN (yang kini digantikan SNBP) memisahkan calon mahasiswa berdasarkan jurusan di asal sekolahnya.\r\n\r\nContoh, siswa IPA akan diseleksi berdasarkan nilai Kimia, Fisika, Biologi, Matematika, Bahasa Indonesia, dan Bahasa Inggris.\r\n\r\nSementara itu, siswa IPS akan diseleksi berdasarkan nilai Geografi, Ekonomi, Sosiologi, Matematika, Bahasa Indonesia, dan Bahasa Inggris.\r\n\r\nKemendikbudristek menjelaskan, tujuan nilai rata-rata rapor seluruh mata pelajaran menjadi komponen seleksi SNBP 2023 yaitu agar siswa terdorong untuk berprestasi di seluruh mata pelajaran secara menyeluruh.\r\n\r\n\"(Sebelumnya di SNMPTN), hanya pelajaran tertentu yang dipertimbangkan dalam seleksi sehingga mata pelajaran lain dianggap tidak penting dan fokus pembelajaran tidak menyeluruh,\" jelas Kemendikbudristek dalam akun resminya, @kemdikbud.ri, dikutip Senin (30/1/2023).\r\n\r\n\"Bagaimana pun, seluruh mata pelajaran penting untuk mendukung minat dan bakatmu. Jadi, tetapi semangat belajar, ya,\" imbuhnya.\r\n\r\nLebih lanjut, pilihan prodi di SNMPTN sebelumnya juga dibatasi berdasarkan jurusan di pendidikan menengah, sehingga siswa tidak punya kesempatan mengeksplorasi minat dan aspirasi bakatnya.\r\n\r\nSementara itu, siswa di SNBP kini bisa lintas jurusan atau memilih prodi apa saja sesuai minatnya. Mendukung kebijakan ini, berikut sejumlah ketentuan seleksi di SNBP 2023:\r\n\r\nSeleksi di SNBP 2023\r\nTersedia prodi tujuan S1, D4, dan D3 di SNBP 2023.\r\nKomponenpenilaianSNBP 2023 terdiri dari:\r\n1) nilai rata-rata rapor seluruh mata pelajaran (bobot minimal 50 persen)\r\n2) komponen penggali minat dan bakat (bobot maksimal 50 persen), terdiri dari\r\n- Nilai rapor dari maksimal 2 mata pelajaran pendukung\r\n- Prestasi\r\n- Portofolio (untuk tujuan prodi seni dan olahraga).\r\nMata pelajaran (mapel) pendukung setiap prodi pilihan di SNBP 2023 dapat dilihat di Keputusan Mendikbudristek RI Nomor 345/M/2022, unduh di sini.\r\nPTN menentukan komposisi persentase komponen 1 dan 2 dengan total 100 persen.\r\nPTN menentukan sub komponen untuk komponen 2 beserta komposisi persentase bobotnya.\r\nSetiap prodi di satu PTN dapat memiliki komposisi persentase komponen 1& 2 serta sub komponen 2 & komposisi persentase yang berbeda.\r\nKriteria dan penetapan hasil kelulusan SNBP 2023 merupakan kewenangan pimpinan PTN.\r\nSebelumnya Ketua Umum Seleksi Nasional Penerimaan Mahasiswa Baru (SNPMB) 2023 Prof Mochamad Ashari mengatakan, siswa peserta SNBP juga dapat mempertimbangkan kecocokan antara keistimewaan diri dan minat diri untuk memilih sebuah prodi.\r\n\r\n\"Memilih prodi teknik misalnya, komponen utamanya fisika, lalu elektro itu matematika. Itu akan diambil sebagai bagian persentase nilai tadi sehingga Anda agak sedikit kurang matching kalau nggak sesuai. Tetapi tetap ada nilainya. Jadi bila nilai bagus, saat disandingkan (dengan nilai lain) bisa menang, tetapi potensi untuk berhasil adalah orang-orang yang cocok,\" kata Ashari dalam konferensi pers SNPMB, disiarkan daring, Selasa (10/1/2023).', 'Y', 'Y', 'Y', 9, 'ef8deec749133d624fcb6ad76212ca84.jpeg', 'Y', '2023-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `id` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `sub_title` varchar(50) NOT NULL,
  `sub_url` varchar(50) NOT NULL,
  `is_active` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`id`, `id_menu`, `sub_title`, `sub_url`, `is_active`) VALUES
(1, 1, 'Identitas Web', 'admin/identity', 'Y'),
(2, 1, 'Kontak', 'admin/contact', 'Y'),
(3, 2, 'Menu Utama', 'admin/menu', 'Y'),
(4, 2, 'Sub Menu', 'admin/submenu', 'Y'),
(5, 3, 'Kategori', 'admin/category', 'Y'),
(6, 3, 'Posting', 'admin/posting', 'Y'),
(7, 4, 'Album', 'admin/album', 'N'),
(8, 4, 'Gallery Foto', 'admin/gallery', 'N'),
(10, 4, 'Banner', 'admin/banner', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$12$bF/4oAmyFIPE15bH3gFpKuaWvqzJGA6tB7iZ.hEoBdpQpT66C/oKC', 'adminsija@gmail.com', NULL, '', NULL, NULL, NULL, NULL, NULL, 1268889823, 1675300868, 1, 'sija', 'update', NULL, '0895802715273');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(39, 1, 1),
(40, 1, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `identity`
--
ALTER TABLE `identity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posting`
--
ALTER TABLE `posting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_email` (`email`),
  ADD UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  ADD UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  ADD UNIQUE KEY `uc_remember_selector` (`remember_selector`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `identity`
--
ALTER TABLE `identity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `posting`
--
ALTER TABLE `posting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `submenu`
--
ALTER TABLE `submenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
