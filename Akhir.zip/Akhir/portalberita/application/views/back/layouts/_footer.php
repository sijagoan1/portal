<footer class="sticky-footer bg-white">
   <div class="container my-auto">
      <div class="copyright text-center my-auto">
      <span>Copyright &copy; SIJA UPDATE.com 2023</span>
      </div>
   </div>
</footer>